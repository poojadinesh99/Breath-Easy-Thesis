package com.example.breath_easy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
